package day19;

import java.util.ArrayList;

public class Task2 {
	public static void main(String[] args) {
//		 Remove duplicate elements from a List
//		 Question:
//		 Given a list of integers with duplicates, remove duplicates without using Set.
		
		
//		Arraylist with Duplicates
		
		ArrayList<Integer> al = new ArrayList<Integer>();
		al.add(1);
		al.add(2);
		al.add(3);
		al.add(2);
		al.add(3);
		al.add(3);
		al.add(4);
		al.add(4);
		System.out.println(al);
		
//      to remove
		
		for(int i=0;i<=al.size()-1;i++) {
			for(int j=i+1;j<=al.size()-1;j++) {
				if(al.get(i).equals(al.get(j))) {
					al.remove(j);
					j--;
				}
			}
		}System.out.println(al);
		
		
		
		
		
	}

}
