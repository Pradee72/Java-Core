package day19;

public class Task4and5 {
	public static void main(String[] args) {



		
		
//		Right-Angled Triangle (Stars)
//
//		output:
//
//		*
//		*	*
//		*	*	*
//		*	*	*	*
//		*	*	*	*	*
		System.out.println("Right Angled Triangle!!");
		for(int i = 1; i <= 5; i++) {
			for(int j=1; j <= i; j++) {
				System.out.print("*\t");
			}
		System.out.println();
		}
		System.out.println();
//		5.Inverted Triangle program
//		output:
//
//		*	*	*
//		*	*
//		*
		System.out.println("Inverted Triangle program!!");
		for(int i = 1;i <= 3; i++) {
			for(int j=3;j>=i;j--) {
				System.out.print("*\t");
			}System.out.println();
		}
		
		


	
	}

}
