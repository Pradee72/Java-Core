package day19;

public class Task3 {
	public static void main(String[] args) {
//		 Synchronize an ArrayList
//		 Question:
//		 Make ArrayList thread-safe and iterate over it.
		
		

	}

}
