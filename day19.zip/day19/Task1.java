package day19;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Task1 {
	public static void main(String[] args) {
//		1. Add elements and iterate using different methods
//		Question:
//			Write a program to add 5 names to an ArrayList and print them using:
//			For loop
//			Enhanced for loop
//			Iterator
		
		ArrayList<String> al = new ArrayList<String>();
		Scanner sc = new Scanner(System.in);
		for(int i=0;i<=4;i++) {
			System.out.println("Enter the "+i+"st name :");
			al.add(sc.nextLine());
		}
		System.out.println(al);
//		
//		al.add("dog");
//		al.add("cat");
//		al.add("bird");
//		al.add("lion");
//		al.add("frog");
//		System.out.println(al);
//		
		
		// using for
		System.out.println("Using basic For :");
		for(int i=0;i<=al.size()-1;i++) {
			System.out.println(al.get(i));
		}
		
//		using enhanced for loop
		System.out.println("Using basic For :");
		for(String c : al) {
			System.out.println(c);
		}
		
//		using iterator
		Iterator<String> its = al.iterator();
		System.out.println("Using Iterator() :");
		while(its.hasNext()) {
			System.out.println(its.next());
		}


	}

}
