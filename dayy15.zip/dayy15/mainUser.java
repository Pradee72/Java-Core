package dayy15;

public class mainUser {
	public static void main(String[] args) {
		library std1=new library(1,"harry Potter","jk rowling",100);
		library std2=new library(2,"vicky the great","vicky b",200);
		System.out.println(std1);
		System.out.println(std2);
	}

}
